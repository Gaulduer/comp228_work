package interfaces;

public interface QueueInterface<E> {
	void enqueue(E element);
	E dequeue();
	boolean isEmpty();
	boolean isFull();
}
