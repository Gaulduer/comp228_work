package apps;

/*
 * Peter Gauld
 * Queue Driver - This program is meant to run and test the ArrayQ and LLQ classes.\
 * 2/13/2022 - File Created.
 */

import java.util.Scanner;

public class QueueDriver {
	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		run(read);
		read.close();
	}
	
	public static void run(Scanner read) {
		int decision = 0;
		int exit = 3; //This is the value on which the program will exit.
		
		while(decision != exit) {
			try {
				System.out.println("What queue would you like to run?:\n1)Run Array Queue\n2)Run Linked List Queue\n3)Stop Running Queues\n");
				decision = read.nextInt();
				if(decision == 1) {
					ArrayQDriver.run();
				}
				else if(decision == 2) {
					LLQDriver.run();
				}
				else if(decision == exit) {
					//Do nothing.
				}
				else {
					System.out.println("Please enter a valid option.");
				}
			}
			catch(Exception e) {
				read.next();
				decision = 0;
				System.out.println("Please enter a number!");
			}
		}
	}
}
