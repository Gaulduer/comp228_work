package apps;

import java.util.Scanner;

public class MainDriver {
	public static void main(String[]args) {
		Scanner read = new Scanner(System.in);
		int decision = 0;
		int exit = 3; //This is the value on which the program will exit.
		
		while(decision != exit) {
			try {
				System.out.println("What would you like to run?:\n1)Run Stack\n2)Run Queue\n3)Stop Running Programs\n");
				decision = read.nextInt();
				if(decision == 1) {
					new StackDriver();
				}
				else if(decision == 2) {
					QueueDriver.run(read);
				}
				else if(decision == exit) {
					//Do nothing.
				}
				else {
					System.out.println("Please enter a valid option.");
				}
			}
			catch(Exception e) {
				read.next();
				System.out.println("Please enter a number!");
			}
		}
		try {
			read.close();
		}
		catch(Exception e) {
			//Do nothing.
		}
	}
	
	public static void runStack() {
		new StackDriver();
	}
	
	public static void runQueue() {
		new QueueDriver();
	}
}
