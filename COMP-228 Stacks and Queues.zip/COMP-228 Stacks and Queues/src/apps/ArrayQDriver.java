package apps;

import adts.ArrayQPeterGauld;

public class ArrayQDriver {
	public static void main(String[] args) {
		run();
	}
	
	public static void run() {
		ArrayQPeterGauld<String> queue = new ArrayQPeterGauld<>();
		
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		queue.enqueue("Peter");
		queue.enqueue("Alex");
		queue.enqueue("Natalee");
		queue.enqueue("Maria");
		queue.dequeue();
		queue.enqueue("Lilith");
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		
		System.out.println(queue);
	}
}
