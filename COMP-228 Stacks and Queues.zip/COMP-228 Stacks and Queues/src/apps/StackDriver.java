package apps;

/*
 * Peter Gauld
 * Stack Driver - A program meant to run and test the Array Stack Class.
 * 2/10/2022 - File Created.
 */

import adts.ArrayStack;

public class StackDriver {
	public StackDriver() {
		ArrayStack<Integer> intStack = new ArrayStack<>(10);
		intStack.push(1);
		intStack.pop();
		System.out.println(intStack);
	}
}
