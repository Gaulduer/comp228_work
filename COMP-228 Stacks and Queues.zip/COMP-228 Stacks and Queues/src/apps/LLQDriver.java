	package apps;

/*
 * Peter Gauld
 * Linked List Queue Driver - A driver program for the Linked List Queue Program
 */

import adts.LLQPeterGauld;
import alts.AlternativeLLQ;

public class LLQDriver {
	public static void main(String[] args) {
		run();
	}
	
	public static void run() {
		LLQPeterGauld<String> queue = new LLQPeterGauld<>();
		
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		queue.enqueue("Peter");
		queue.enqueue("Alex");
		queue.enqueue("Natalee");
		queue.enqueue("Maria");
		queue.dequeue();
		queue.enqueue("Lilith");
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		
		System.out.println(queue);		
	}
	
	public static void runAlternate() {
		//LLQPeterGauld<String> queue = new LLQPeterGauld<>();
		AlternativeLLQ<String> queue = new AlternativeLLQ<>();
		
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		queue.enqueue("Peter");
		queue.enqueue("Alex");
		queue.enqueue("Natalee");
		queue.enqueue("Maria");
		queue.dequeue();
		queue.enqueue("Lilith");
		System.out.println(queue.isEmpty());
		System.out.println(queue.isFull());
		
		System.out.println(queue);		
	}
}
