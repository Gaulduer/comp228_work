package stack;

public class Stack<T> implements StackInterface<T>{
	private T[] stackArray; //This array holds the values of the stack
	
	//Constructor
		@SuppressWarnings("unchecked")
		public Stack(int size) {
			stackArray = (T[]) new Object[size];
		}
	
	//Stack Interface Methods
		public void push(Object input) {
			
		}
		
		public T pop() {
			T output = stackArray[indexOnTop()]; //Get the element on top
			stackArray[indexOnTop()] = null; //Set the top element to null
			return output; //Return the element that was on top.
		}
		
		public T peek() {
			return stackArray[indexOnTop()];
		}
	
		public boolean isEmpty() {
			return false;
		}
		
		public boolean isFull() {
			return false;
		}
	
	//Private Methods
		private int indexOnTop() {
			int index = 0;
			
			return index;
		}
}
