package alts;

import nodes.LLNode;

public class AlternativeLLQ<E> {
	//This version makes the 'isFull' useful by creating an artificial list size.
	
	private LLNode<E> first; //This Node holds the element at the front of the Queue
	private LLNode<E> last; //This Node holds the element at the back of the Queue
	
	protected int numberOfElements = 0;
	protected int capacity = 0;
	protected final int DEFAULT_CAPACITY = 4;
	
	//Constructor
		public AlternativeLLQ() {
			capacity = DEFAULT_CAPACITY;
		}
	
		public AlternativeLLQ(int capacity) {
			this.capacity = capacity;
		}
		
	//Queue Interface Methods
		public void enqueue(E element) {
			if(isFull()) //If the queue is full, do not add the new element.
				return;
			
			LLNode<E> node = new LLNode<E>(element);
			if(isEmpty()) { //If the queue is empty, set the first node as a new node including the element.
				first = node;
				last = first;
			}
			else { //Otherwise add the node to the end of the list.
				last.setNext(node);
				last = node;
			}
			numberOfElements++;
		}
		
		public E dequeue() {
			if(isEmpty()) //If the queue is empty, do not remove or return an element.
				return null;
			LLNode<E> node = first;
			first = first.getNext();
			numberOfElements--;
			return node.getData();
		}
		
		public boolean isEmpty() {
			if(first == null) //If first is null, the queue is empty.
				return true;
			return false;
		}
		
		public boolean isFull() {
			if(numberOfElements == capacity) //If the number of elements is equal to the capacity, the queue is full.
				return true;
			return false;
		}
		
	//Utility Methods
		public String toString() {
			if(isEmpty()) //If the queue is empty, tell the user this is the case.
				return "This queue is empty.";
			
			String output = "Linked List Queue, front to back: ";
			LLNode<E> placeInLine = first;
			while(placeInLine != null) {
				output += placeInLine.getData() + " ";
				placeInLine = placeInLine.getNext();
			}
			
			return output;
		}
}
