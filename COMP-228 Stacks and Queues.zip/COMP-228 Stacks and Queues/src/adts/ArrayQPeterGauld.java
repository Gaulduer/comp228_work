package adts;

/*
 * Peter Gauld
 * Array Queue - A Queue class based on an array.
 * 
 * 2/11/2022 - File created. 
 * Queue Interface Methods implemented and functional. 
 * 'toString' method added.
 * 
 * 2/14/2022 - Changes made to how first and last are used by the program. 
 * In the 'dequeue' method, if first "passes" last, their values are reset to 0 and -1 respectively. 
 * 'isEmpty' method now looks to see if last is below 0 to consider the array empty. Previously it checked if first and last where equal.
 * 'isFull' method now checks if isEmpty is true. Previously it only checked if first was one spot ahead of last.
 * 'toString' method now uses a do while loop. Previously it uses a for loop. 
 * Queue Array no longer requires an extra space as a result to these changes.
 */
	
import interfaces.QueueInterface;

public class ArrayQPeterGauld<E> implements QueueInterface<E> {
	private E[] queueArray; //This array holds the values of the stack
	protected int first = 0; //This tracks the position at the start of the queue. First is set to 0. The position matters so that when something is queued last will match up with first.
	protected int last = -1; //This tracks the position at the end of the queue. Last is set to -1, so it will be less than 0 while nothing is in the queue.
	protected final int DEFAULT_CAPACITY = 4;
	
	//Constructor
		@SuppressWarnings("unchecked")
		public ArrayQPeterGauld() {
			queueArray = (E[]) new Object[DEFAULT_CAPACITY ];
		}
	
		@SuppressWarnings("unchecked")
		public ArrayQPeterGauld(int capacity) {
			queueArray = (E[]) new Object[capacity];
		}
	
	//Queue Interface Methods
		public void enqueue(E element) {
			if(isFull()) //If the queue is full, do not add the new element.
				return;
			last = (last + 1) % (queueArray.length); //Move up last and keep it in the bounds of the array
			queueArray[last] = element;
		}
		
		public E dequeue() {
			if(isEmpty()) //If the queue is empty, do not remove or return an element.
				return null;
			E element = queueArray[first];
			first = (first + 1) % (queueArray.length); //Move up first and keep it in the bounds of array.
			if(isFull()) { //If 'isFull' returns true first has passed last, reset first and last. The queue at this point should be empty. This situation does not get confused with the queue actually being full, as if an element has just been removed the queue cannot be full.
				first = 0; //First is set to 0. The position matters so that when something is queued last will match up with first.
				last = -1; //Last is set to -1, so it will be less than 0 while nothing is in the queue.
			}
			return element;
		}
		
		public boolean isEmpty() {
			if(last < 0) //If last is below 0, the queue is empty.
				return true;
			return false;
		}
		
		public boolean isFull() {
			if((last + 1) % (queueArray.length) == first && !isEmpty()) //If the next spot on the array from the last is the first, unless 'isEmpty' returns true, the queue is full.
				return true;
			return false;
		}
		
	//Utility Methods
		public String toString() {
			if(isEmpty()) //If the queue is empty, tell the user this is the case.
				return "This stack is empty.";
				
			String output = "Array Queue, front to back: ";
			int placeInQueue = first;
			do //Do while 'placeInQueue' has not passed last on the array. A do while is used in case last + 1 is equal to first.
				output += queueArray[placeInQueue++ % queueArray.length] + " ";
			while((placeInQueue % queueArray.length) != ((last + 1) % (queueArray.length))); 
			
			return output;
		}
}