package adts;

/*
 * Peter Gauld
 * Array Queue - A Queue class based on an linked list.
 * 2/11/2022 - File created. Queue Interface Methods implemented and functional (Possibly excluding 'isFull'). 'toString' method added.
 * 2/13/2022 - A separate alternative class was created to make us of the 'isFull' method. Instead of simply returning false, the program will artificially limit the size of the linked list.
 */
	
import interfaces.QueueInterface;
import nodes.LLNode;

public class LLQPeterGauld<E> implements QueueInterface<E> {
	private LLNode<E> first; //This Node holds the element at the front of the Queue.
	private LLNode<E> last; //This Node holds the element at the back of the Queue.
		
	//Queue Interface Methods
		public void enqueue(E element) {
			LLNode<E> node = new LLNode<E>(element);
			if(isEmpty()) { //If the queue is empty, set the first node as a new node including the element.
				first = node;
				last = first;
			}
			else { //Otherwise add the node to the end of the list.
				last.setNext(node);
				last = node;
			}
		}
		
		public E dequeue() {
			if(isEmpty()) //If the queue is empty, do not remove or return an element.
				return null;
			LLNode<E> node = first;
			first = first.getNext();
			return node.getData();
		}
		
		public boolean isEmpty() {
			if(first == null) //If first is null, the queue is empty.
				return true;
			return false;
		}
		
		public boolean isFull() {
			return false;
		}
		
	//Utility Methods
		public String toString() {
			if(isEmpty()) //If the queue is empty, tell the user this is the case.
				return "This queue is empty.";
			
			String output = "Linked List Queue, front to back: ";
			LLNode<E> placeInLine = first;
			while(placeInLine != null) {
				output += placeInLine.getData() + " ";
				placeInLine = placeInLine.getNext();
			}
			
			return output;
		}
}

