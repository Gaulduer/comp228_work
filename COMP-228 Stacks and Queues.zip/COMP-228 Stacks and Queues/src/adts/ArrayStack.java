package adts;

/*
 * Peter Gauld
 * Array Stack - A Stack class based on an array.
 * 2/10/2022 - File created. Stack Interface methods implemented and functional. 'toString' method created.
 */

import interfaces.StackInterface;

public class ArrayStack<E> implements StackInterface<E> {
	private E[] stackArray; //This array holds the values of the stack
	protected int top = -1;
	protected final int DEFAULT_CAPACITY = 4;
	
		//Constructor
			@SuppressWarnings("unchecked")
			public ArrayStack(int size) {
				stackArray = (E[]) new Object[size];
			}
		
		//Stack Interface Methods
			public void push(E input) {
				if(!isFull()) //If the array is not full, then the input can be added.
					stackArray[++top] = input;
			}
			
			public E pop() {
				E output = stackArray[top]; //Get the element on top
				if(!isEmpty()) //If the array is not empty, then the element can be removed.
					stackArray[top--] = null; //Set the top element to null. Also decrement top.
				return output; //Return the element that was on top.
			}
			
			public E peek() {
				return stackArray[top];
			}
		
			public boolean isEmpty() {
				if(top < 0) //If the top is placed below 0, the array should be empty
					return true;
				return false;
			}
			
			public boolean isFull() {
				if(top == stackArray.length - 1) //If the top is at the highest possible index, the array should be full.
					return true;
				return false;
			}
			
		//Utility Methods
			public String toString() {
				if(isEmpty()) //If the stack is empty, tell the user this is the case.
					return "This stack is empty.";
					
				String output = "Stack, top to bottom:\n";
				for(int i = top; i >= 0 ; i--)
					output += stackArray[i] + "\n";
				
				return output;
			}
}
